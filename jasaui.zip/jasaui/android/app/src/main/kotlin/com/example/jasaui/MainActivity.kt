package com.example.jasaui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
